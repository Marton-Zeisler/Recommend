//#-hidden-code
import PlaygroundSupport
let exampleSelectionVC = ExampleSelectionVC.loadFromStoryboard() as! ExampleSelectionVC
PlaygroundPage.current.liveView = exampleSelectionVC
PlaygroundPage.current.needsIndefiniteExecution = true
//#-end-hidden-code
//: ## Calculating the Recommendations
//: Pick an item and we will walk you through step-by-step how to compute the best recommendation for your selection.
//: ### Step 1
//: The first step is to gather the vector of your selected item from the database. The elements of the vector indicate whether the corresponding user placed an order on that item previously.
//: ### Step 2
//: Next, you will need to get the vectors for the other items as well. These are needed to compute the similarity measure between your selection and the other items.
//: ### Step 3
//: Now that you have the vectors for your selection and the other items, it's time to do some math. We need to measure the similarity values between the items, and one way to do that is to measure the cosine of the angle between the two vectors:
//:
//: ![The cosine-based similarity](pic1.png)
//:
//: The computed angle can range from 0° degress to 90° degrees. A 0° degree indicates 100% similarity between the two items and a 90° degree means there is no similarity at all between the two items.
//: ### Step 4
//: After we measured the similarities between your selection and every other items, the last step is to find the pair of items with the **smallest angle**. This will allow you to find out which item is the best recommendation for you.
//: - - -
//: ## [Next page](@next)
