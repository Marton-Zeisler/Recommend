import PlaygroundSupport

let exampleSelectionVC = ExampleSelectionVC.loadFromStoryboard() as! ExampleSelectionVC
PlaygroundPage.current.liveView = exampleSelectionVC
PlaygroundPage.current.needsIndefiniteExecution = true
