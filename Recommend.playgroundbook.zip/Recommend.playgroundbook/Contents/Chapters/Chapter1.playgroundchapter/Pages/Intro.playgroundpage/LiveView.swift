import PlaygroundSupport
let introVC = IntroVC.loadFromStoryboard() as! IntroVC
PlaygroundPage.current.liveView = introVC
PlaygroundPage.current.needsIndefiniteExecution = true
