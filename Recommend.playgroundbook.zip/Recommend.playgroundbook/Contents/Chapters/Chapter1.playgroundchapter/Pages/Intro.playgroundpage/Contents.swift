//#-hidden-code
import PlaygroundSupport
let introVC = IntroVC.loadFromStoryboard() as! IntroVC
PlaygroundPage.current.liveView = introVC
PlaygroundPage.current.needsIndefiniteExecution = true
//#-end-hidden-code
//: # Introduction to Collaborative Filtering
//: Welcome to my Swift Playground where you will learn about how personalized recommendation systems work.
//: - - -
//: ## What is a Recommender Engine?
//: Recommendation algorithms are best known for their use on e-commerce websites, where the algorithms take the input of a user’s interests and based on that, generate a list of suggested, recommended items.
//:
//: ### Types of Recommendation Systems
//: **Collaborative filtering** uses the known behavior of a group of users to make recommendations for others. For example, by using the data from other users who have similar preferences about a group of items, you can predict whether a particular user is likely to be interested in an item.
//:
//: **Content-based filtering** makes use of the comparison between items and the past preferences of a particular user. That is, the items which have similar properties to the ones that the user liked or checked previously are likely to be recommended.
//:
//: ## Item-to-Item Collaborative Filtering
//: Item-based collaborative filtering was launched by Amazon.com in 1998, which dramatically improved the scalability of recommender systems. The algorithm calculates the similarities between different items in the dataset, then these similarity values are used to predict ratings for user-item pairs not present in the dataset.
//: - - -
//: ## [Next page](@next)
