//#-hidden-code
import PlaygroundSupport
let filteringVC = FilteringTableVC.loadFromStoryboard() as! FilteringTableVC
PlaygroundPage.current.liveView = filteringVC
PlaygroundPage.current.needsIndefiniteExecution = true
//#-end-hidden-code
//: ## Item-based Filtering
//: As you finished making purchases on the previous page, the database has been configured based on your selections. You can now see the item-based filtering table. A blue tick indicates that the user purchased the item and the red cross indicates the opposite.
//: ## Item-to-Item Vectors
//: Tap on the blue button to reveal the [vectors](glossary://vector) for your items. These vectors represent the purchase history for each item, and these vectors give us the quantifiable measure of how similar they are to each other.
//:
//: - Important: The vectors are 3 dimensional because this system only has three users. Each element in the vector indicates whether the corresponding user purchased the item or not. 1 means the user previously purchased the item, and 0 means the user didn't purchase the item.
//:
//: The order of the elements in the vector is important. The order of the users lined up next to each item defines the order of elements for each vector as well. So the first element in a vector tells us whether the first user bought it or not.
//: - - -
//: ## [Next page](@next)
