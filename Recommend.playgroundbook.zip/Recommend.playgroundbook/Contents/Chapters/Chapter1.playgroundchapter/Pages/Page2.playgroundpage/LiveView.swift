import PlaygroundSupport

let filteringVC = FilteringTableVC.loadFromStoryboard() as! FilteringTableVC
PlaygroundPage.current.liveView = filteringVC
PlaygroundPage.current.needsIndefiniteExecution = true
