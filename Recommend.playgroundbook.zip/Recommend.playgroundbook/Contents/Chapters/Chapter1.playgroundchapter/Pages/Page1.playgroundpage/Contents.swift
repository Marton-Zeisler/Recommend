//#-hidden-code
import PlaygroundSupport
let basketVC = BasketVC.loadFromStoryboard() as! BasketVC
PlaygroundPage.current.liveView = basketVC
PlaygroundPage.current.needsIndefiniteExecution = true
//#-end-hidden-code
//: ## Creating the Data
//: You will create the [data set](glossary://data-set) for the recommendation system by helping these users to make purchases.
//: ### Instructions:
//: * **Drag and drop** any of the items to the users' shopping basket to make a purchase.
//:
//: The recommendation system will use this data set to build the item-to-item collaborative filtering table and assign the item-based vectors for each item.
//: ### Reset
//: The program will remove most of your selections and will generate a few selections, in order to keep the recommendation system working for each user.
//: ### Randomize
//: The system will assign random purchases for each of the three users.
//: - - -
//: ## [Next page](@next)

