import PlaygroundSupport

let gameSelectionVC = GameSelectionVC.loadFromStoryboard() as! GameSelectionVC
PlaygroundPage.current.liveView = gameSelectionVC
PlaygroundPage.current.needsIndefiniteExecution = true
