//#-hidden-code
import PlaygroundSupport
let gameSelectionVC = GameSelectionVC.loadFromStoryboard() as! GameSelectionVC
PlaygroundPage.current.liveView = gameSelectionVC
PlaygroundPage.current.needsIndefiniteExecution = true
//#-end-hidden-code
//: ## Test the system with multiple items
//: Finally, you can further test your data set of items by placing one or two items in your own basket and see what additional item the system recommends you to purchase. The program will also give you an explanation to help you better understand the result.
//: ### When adding 2 items
//: If you place two items in your basket, the system will check to see if the best-recommended items for you are not already in your basket.
//: - - -
//: #### Disclaimer:
//: Object and Background illustrations were used and modified from an open-source, provided by freepik.com.
//:
//: Character illustrations were used and modified from an open-source, provided by avataaars.com.
//:
//: "Muli" font is an open-source font, provided by fonts.google.com.
//:
//: Intro background music is from Royalty Free, free music library, provided by Purple Planet Music
//:
//: The design of “RECOMMEND” playground was done by Marton Zeisler.
//:
//: “RECOMMEND” is a project by Marton Zeisler.
