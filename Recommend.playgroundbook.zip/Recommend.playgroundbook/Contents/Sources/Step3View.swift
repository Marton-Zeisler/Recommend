//
//  Step3View.swift
//  Book_Sources
//
//  Created by Marton Zeisler on 2019. 03. 18..
//

import UIKit

class Step3View: UIView{
    
    @IBOutlet var contentView: UIView!
    
    @IBOutlet weak var calculateButton: UIButton!
    @IBOutlet weak var continueButton: UIButton!
    @IBOutlet weak var stackView: UIStackView!
    @IBOutlet var heightConstraint: NSLayoutConstraint!
    
    weak var stepViewDelegate: StepViewDelegate?
    
    @IBOutlet var selectedItem1: UIImageView!
    @IBOutlet var selectedItem2: UIImageView!
    @IBOutlet var selectedItem3: UIImageView!
    
    @IBOutlet var pair1: UIImageView!
    @IBOutlet var pair2: UIImageView!
    @IBOutlet var pair3: UIImageView!
    
    @IBOutlet var pair1Vector: UILabel!
    @IBOutlet var pair2Vector: UILabel!
    @IBOutlet var pair3Vector: UILabel!
    
    @IBOutlet var stepLabel: UILabel!
    
    @IBOutlet var titleLabel: UILabel!
    
    @IBOutlet var vs1Label: UILabel!
    @IBOutlet var vs2Label: UILabel!
    @IBOutlet var vs3Label: UILabel!
    
    @IBOutlet var whiteView: UIView!
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setups()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        setups()
    }
    
    func setups(){
        let nib = UINib(nibName: "Step3View", bundle: .main)
        nib.instantiate(withOwner: self, options: nil)
        
        self.addSubview(self.contentView)
        self.contentView.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            self.contentView.topAnchor.constraint(equalTo: self.topAnchor),
            self.contentView.bottomAnchor.constraint(equalTo: self.bottomAnchor),
            self.contentView.leadingAnchor.constraint(equalTo: self.leadingAnchor),
            self.contentView.trailingAnchor.constraint(equalTo: self.trailingAnchor),
            ])
        
        // Shadow
        whiteView.layer.shadowColor = UIColor.black.cgColor
        whiteView.layer.shadowOpacity = 0.2
        whiteView.layer.shadowOffset = .zero
        whiteView.layer.shadowRadius = 10
        
        // Font
        var fontURL = Bundle.main.url(forResource: "Muli-Bold", withExtension: "ttf")
        CTFontManagerRegisterFontsForURL(fontURL! as CFURL, CTFontManagerScope.process, nil)
        fontURL = Bundle.main.url(forResource: "Muli-SemiBold", withExtension: "ttf")
        CTFontManagerRegisterFontsForURL(fontURL! as CFURL, CTFontManagerScope.process, nil)
        
        stepLabel.font = UIFont(name: "Muli-Bold", size: 18)
        titleLabel.font = UIFont(name: "Muli-SemiBold", size: 16)
        vs1Label.font = UIFont(name: "Muli-Bold", size: 15)
        vs2Label.font = UIFont(name: "Muli-Bold", size: 15)
        vs3Label.font = UIFont(name: "Muli-Bold", size: 15)
        pair1Vector.font = UIFont(name: "Muli-Bold", size: 22)
        pair2Vector.font = UIFont(name: "Muli-Bold", size: 22)
        pair3Vector.font = UIFont(name: "Muli-Bold", size: 22)
    }
    
    func setupUI(selectedItem: Item, pair1Item: Item, pair1Angle: Double, pair2Item: Item, pair2Angle: Double, pair3Item: Item, pair3Angle: Double){
        selectedItem1.image = UIImage(named: selectedItem.getWhiteImage())
        selectedItem2.image = UIImage(named: selectedItem.getWhiteImage())
        selectedItem3.image = UIImage(named: selectedItem.getWhiteImage())
        
        pair1.image = UIImage(named: pair1Item.getWhiteImage())
        pair2.image = UIImage(named: pair2Item.getWhiteImage())
        pair3.image = UIImage(named: pair3Item.getWhiteImage())
        
        pair1Vector.text = "= \(Int(round(pair1Angle)))" + "°" + " [\(Int(abs(((pair1Angle-90)/90) * 100)))% MATCH]"
        pair2Vector.text = "= \(Int(round(pair2Angle)))" + "°" + " [\(Int(abs(((pair2Angle-90)/90) * 100)))% MATCH]"
        pair3Vector.text = "= \(Int(round(pair3Angle)))" + "°" + " [\(Int(abs(((pair3Angle-90)/90) * 100)))% MATCH]"
    }
    
    @IBAction func calculateTapped(_ sender: Any) {
        heightConstraint.isActive = false
        continueButton.isHidden = false
        calculateButton.isHidden = true
        stackView.isHidden = false
    }
    
    @IBAction func continueTapped(_ sender: Any) {
        stepViewDelegate?.nextTapped()
    }
    
    
    
}


