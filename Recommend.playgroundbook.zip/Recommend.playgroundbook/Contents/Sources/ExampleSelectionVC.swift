//
//  ExampleSelectionVC.swift
//  Book_Sources
//
//  Created by Marton Zeisler on 2019. 03. 17..
//

import UIKit

public class ExampleSelectionVC: UIViewController {
    
    @IBOutlet var whiteView: UIView!
    
    @IBOutlet weak var glassesButton: UIButton!
    @IBOutlet weak var cameraButton: UIButton!
    @IBOutlet weak var bagButton: UIButton!
    @IBOutlet weak var headphonesButton: UIButton!
    
    @IBOutlet weak var glassesTick: UIImageView!
    @IBOutlet weak var cameraTick: UIImageView!
    @IBOutlet weak var bagTick: UIImageView!
    @IBOutlet weak var headphonesTick: UIImageView!
    
    var selectedItem: Item = .none
    
    @IBOutlet var exampleLabel: UILabel!
    @IBOutlet var instructionLabel: UILabel!
    @IBOutlet var showButton: UIButton!
    
    override public func viewDidLoad() {
        super.viewDidLoad()
        
        // Shadow
        whiteView.layer.shadowColor = UIColor.black.cgColor
        whiteView.layer.shadowOpacity = 0.2
        whiteView.layer.shadowOffset = .zero
        whiteView.layer.shadowRadius = 10

    }
    
    public override func viewWillAppear(_ animated: Bool) {
        var fontURL = Bundle.main.url(forResource: "Muli-Bold", withExtension: "ttf")
        CTFontManagerRegisterFontsForURL(fontURL! as CFURL, CTFontManagerScope.process, nil)
        fontURL = Bundle.main.url(forResource: "Muli-SemiBold", withExtension: "ttf")
        CTFontManagerRegisterFontsForURL(fontURL! as CFURL, CTFontManagerScope.process, nil)
        
        exampleLabel.font = UIFont(name: "Muli-Bold", size: 20)
        instructionLabel.font = UIFont(name: "Muli-SemiBold", size: 19)
        showButton.titleLabel?.font = UIFont(name: "Muli-Bold", size: 16)
    }
    
    @IBAction func glassesTapped(_ sender: Any) {
        selectedItem = .glasses
        glassesButton.setImage(UIImage(imageLiteralResourceName: "itemGlasses.png"), for: .normal)
        glassesTick.isHidden = false
        
        cameraButton.setImage(UIImage(imageLiteralResourceName: "hiddenCamera.png"), for: .normal)
        cameraTick.isHidden = true
        bagButton.setImage(UIImage(imageLiteralResourceName: "hiddenBag.png"), for: .normal)
        bagTick.isHidden = true
        headphonesButton.setImage(UIImage(imageLiteralResourceName: "hiddenHeadphones.png"), for: .normal)
        headphonesTick.isHidden = true
    }
    
    @IBAction func cameraTapped(_ sender: Any) {
        selectedItem = .camera
        cameraButton.setImage(UIImage(imageLiteralResourceName: "itemCamera.png"), for: .normal)
        cameraTick.isHidden = false
        
        glassesButton.setImage(UIImage(imageLiteralResourceName: "hiddenGlasses.png"), for: .normal)
        glassesTick.isHidden = true
        bagButton.setImage(UIImage(imageLiteralResourceName: "hiddenBag.png"), for: .normal)
        bagTick.isHidden = true
        headphonesButton.setImage(UIImage(imageLiteralResourceName: "hiddenHeadphones.png"), for: .normal)
        headphonesTick.isHidden = true
    }
    
    @IBAction func bagTapped(_ sender: Any) {
        selectedItem = .bag
        bagButton.setImage(UIImage(imageLiteralResourceName: "itemBag.png"), for: .normal)
        bagTick.isHidden = false
        
        glassesButton.setImage(UIImage(imageLiteralResourceName: "hiddenGlasses.png"), for: .normal)
        glassesTick.isHidden = true
        cameraButton.setImage(UIImage(imageLiteralResourceName: "hiddenCamera.png"), for: .normal)
        cameraTick.isHidden = true
        headphonesButton.setImage(UIImage(imageLiteralResourceName: "hiddenHeadphones.png"), for: .normal)
        headphonesTick.isHidden = true
    }
    
    @IBAction func headphonesTapped(_ sender: Any) {
        selectedItem = .headphones
        headphonesButton.setImage(UIImage(imageLiteralResourceName: "itemHeadphones.png"), for: .normal)
        headphonesTick.isHidden = false
        
        glassesButton.setImage(UIImage(imageLiteralResourceName: "hiddenGlasses.png"), for: .normal)
        glassesTick.isHidden = true
        cameraButton.setImage(UIImage(imageLiteralResourceName: "hiddenCamera.png"), for: .normal)
        cameraTick.isHidden = true
        bagButton.setImage(UIImage(imageLiteralResourceName: "hiddenBag.png"), for: .normal)
        bagTick.isHidden = true
    }
    
    @IBAction func recommendTapped(_ sender: Any) {
        if selectedItem != .none{
            performSegue(withIdentifier: "showSegue", sender: nil)
        }
    }
    
    public override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "showSegue"{
            let destinationVC = segue.destination as! ExampleShowVC
            destinationVC.selectedItem = selectedItem
        }
    }
    
}

extension ExampleSelectionVC {
    class public func loadFromStoryboard() -> UIViewController? {
        let storyboard = UIStoryboard.init(name: "Main", bundle: nil)
        return storyboard.instantiateViewController(withIdentifier: "ExampleSelectionVC") as! ExampleSelectionVC
    }
}


