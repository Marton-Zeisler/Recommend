//
//  ExampleShowVC.swift
//  Book_Sources
//
//  Created by Marton Zeisler on 2019. 03. 18..
//

import UIKit

public class ExampleShowVC: UIViewController, StepViewDelegate {
    
    @IBOutlet weak var stepLabel: UILabel!
    @IBOutlet weak var pageIndicator: UIPageControl!
    @IBOutlet weak var stepView: UIView!
    @IBOutlet weak var backButton: UIButton!
    
    var step1View: Step1View!
    var step2View: Step2View!
    var step3View: Step3View!
    var step4View: Step4View!
    
    var selectedItem:Item!

    var products = Products()
    
    var stepTexts = [String]()
    
    @IBOutlet var restartButton: UIButton!
    
    override public func viewDidLoad() {
        super.viewDidLoad()
        
        stepTexts.append("You've added \(selectedItem.rawValue) to your basket. Let's find out what the system's recommendation is based on item based collaborative filtering technique")
        stepTexts.append("Let's gather the vectors for the other items in the system")
        stepTexts.append("Let's do some math! We need to compute the similarity values between your selection and the other items")
        stepTexts.append("Final step. Let's find the item with the highest similarity value for your selection")
        stepLabel.text = stepTexts[0]
        
        step1View = Step1View()
        step1View.stepViewDelegate = self
        
        step2View = Step2View()
        step2View.stepViewDelegate = self
        
        step3View = Step3View()
        step3View.stepViewDelegate = self
        
        step4View = Step4View()
        
        setupUI()
        
        stepView.addSubview(step1View)
        step1View.fillSuperView()
    }
    
    public override func viewWillAppear(_ animated: Bool) {
        var fontURL = Bundle.main.url(forResource: "Muli-Bold", withExtension: "ttf")
        CTFontManagerRegisterFontsForURL(fontURL! as CFURL, CTFontManagerScope.process, nil)
        fontURL = Bundle.main.url(forResource: "Muli-SemiBold", withExtension: "ttf")
        CTFontManagerRegisterFontsForURL(fontURL! as CFURL, CTFontManagerScope.process, nil)
        
        stepLabel.font = UIFont(name: "Muli-SemiBold", size: 19)
        backButton.titleLabel?.font = UIFont(name: "Muli-Bold", size: 16)
        restartButton.titleLabel?.font = UIFont(name: "Muli-Bold", size: 16)
        
    }
    
    func setupUI(){
        setupStep1()
        setupStep2()
        setupStep3()
        setupStep4()
    }
    
    func setupStep1(){
        let vector = products.getSelectedItemVector(item: selectedItem)
        step1View.setupUI(selectedItem: selectedItem, selectedVector: vector)
    }
    
    func setupStep2(){
        let (pair1, pair2, pair3) = products.getPairItemVectors(item: selectedItem)
        step2View.setupUI(selectedItem: selectedItem, item1Vector: pair1.1, item2Vector: pair2.1, item3Vector: pair3.1)
    }
    

    func setupStep3(){
        let ((pair1Item, pair1Angle), (pair2Item, pair2Angle), (pair3Item, pair3Angle)) = products.getPairItemAngles(item: selectedItem)
        step3View.setupUI(selectedItem: selectedItem, pair1Item: pair1Item, pair1Angle: pair1Angle, pair2Item: pair2Item, pair2Angle: pair2Angle, pair3Item: pair3Item, pair3Angle: pair3Angle)
    }
    
    func setupStep4(){
        let (matchItem, matchAngle) = products.findLowestPair(item: selectedItem)
        step4View.setupUI(selectedItem: selectedItem, lowestItem: matchItem, lowestAngle: matchAngle)
    }
    
    func nextTapped() {
        animateStepLoad(direction: .right)
    }
    
    @IBAction func restartTapped(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    
    @IBAction func backTapped(_ sender: Any) {
        animateStepLoad(direction: .left)
    }
    
    func loadStep(direction: Direction){
        if direction == .left{
            if pageIndicator.currentPage == 3{
                step4View.removeFromSuperview()
                stepView.addSubview(step3View)
                step3View.fillSuperView()
                backButton.isHidden = false
                pageIndicator.currentPage = 2
            }else if pageIndicator.currentPage == 2{
                step3View.removeFromSuperview()
                stepView.addSubview(step2View)
                step2View.fillSuperView()
                backButton.isHidden = false
                pageIndicator.currentPage = 1
            }else if pageIndicator.currentPage == 1{
                step2View.removeFromSuperview()
                stepView.addSubview(step1View)
                step1View.fillSuperView()
                pageIndicator.currentPage = 0
                backButton.isHidden = true
            }
        }else{
            if pageIndicator.currentPage == 0{
                step1View.removeFromSuperview()
                stepView.addSubview(step2View)
                step2View.fillSuperView()
                pageIndicator.currentPage = 1
                backButton.isHidden = false
            }else if pageIndicator.currentPage == 1{
                step2View.removeFromSuperview()
                stepView.addSubview(step3View)
                step3View.fillSuperView()
                pageIndicator.currentPage = 2
                backButton.isHidden = false
            }else if pageIndicator.currentPage == 2{
                step3View.removeFromSuperview()
                stepView.addSubview(step4View)
                step4View.fillSuperView()
                pageIndicator.currentPage = 3
                backButton.isHidden = false
            }
        }
        
        stepLabel.text = stepTexts[pageIndicator.currentPage]
    }
    
    func animateStepLoad(direction: Direction){
        backButton.isEnabled = false
        let originRects = [stepLabel: stepLabel.frame, stepView: stepView.frame]
        
        UIView.animate(withDuration: 0.5, animations: {
            
            for (eachView, originRect) in originRects{
                var rect = originRect
                rect.origin.x = direction == .right ? self.view.bounds.origin.x - originRect.width : self.view.frame.size.width
                eachView?.frame = rect
            }
            
        }) { (_) in
            
            for (eachView, originRect) in originRects{
                var rect = originRect
                rect.origin.x = direction == .right ? self.view.frame.size.width : self.view.bounds.origin.x - originRect.width
                eachView?.frame = rect
            }
            
            self.loadStep(direction: direction)
            
            UIView.animate(withDuration: 0.5, animations: {
                for (eachView, originRect) in originRects{
                    eachView?.frame = originRect
                }
                self.backButton.isEnabled = true
            })
        }
        
    }
    
    

}

extension ExampleShowVC {
    class public func loadFromStoryboard() -> UIViewController? {
        let storyboard = UIStoryboard.init(name: "Main", bundle: nil)
        return storyboard.instantiateViewController(withIdentifier: "ExampleShowVC") as! ExampleShowVC
    }
}

enum Direction{
    case left
    case right
}
