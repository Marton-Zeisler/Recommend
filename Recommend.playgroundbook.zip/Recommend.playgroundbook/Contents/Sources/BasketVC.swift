//
//  BasketVC.swift
//  Book_Sources
//
//  Created by Marton Zeisler on 2019. 03. 16..
//

import UIKit
import AVFoundation

public class BasketVC: UIViewController{
    
    var audioPlayer: AVAudioPlayer?
    
    @IBOutlet var whiteView: UIView!
    
    // Drag Items
    @IBOutlet weak var dragGlassesImageView: UIImageView!
    @IBOutlet weak var dragCameraImageView: UIImageView!
    @IBOutlet weak var dragBagImageView: UIImageView!
    @IBOutlet weak var dragHeadphonesImageView: UIImageView!
    
    // Person 1
    @IBOutlet weak var person1View: UIView!
    @IBOutlet weak var person1GlassesImageView: UIImageView!
    @IBOutlet weak var person1CameraImageView: UIImageView!
    @IBOutlet weak var person1BagImageView: UIImageView!
    @IBOutlet weak var person1HeadphonesImageView: UIImageView!
    
    // Person 2
    @IBOutlet weak var person2View: UIView!
    @IBOutlet weak var person2GlassesImageView: UIImageView!
    @IBOutlet weak var person2CameraImageView: UIImageView!
    @IBOutlet weak var person2BagImageView: UIImageView!
    @IBOutlet weak var person2HeadphonesImageView: UIImageView!
    
    // Person 3
    @IBOutlet weak var person3View: UIView!
    @IBOutlet weak var person3GlassesImageView: UIImageView!
    @IBOutlet weak var person3CameraImageView: UIImageView!
    @IBOutlet weak var person3BagImageView: UIImageView!
    @IBOutlet weak var person3HeadphonesImageView: UIImageView!
    
    @IBOutlet var instructionLabel: UILabel!
    @IBOutlet var resetButton: UIButton!
    @IBOutlet var randomButton: UIButton!
    @IBOutlet var person1Label: UILabel!
    @IBOutlet var person2Label: UILabel!
    @IBOutlet var person3Label: UILabel!
    
    var products = Products()
    
    @IBOutlet var person1BlueView: UIView!
    @IBOutlet var person2BlueView: UIView!
    @IBOutlet var person3BlueView: UIView!
    
    override public func viewDidLoad() {
        super.viewDidLoad()
    
        setupUI()
        updateUI()
        
        if let path = Bundle.main.path(forResource: "buy.mp3", ofType: nil){
            let url = URL(fileURLWithPath: path)
            do{
                audioPlayer = try AVAudioPlayer(contentsOf: url)
                audioPlayer?.volume = 0.2
            }catch{
                //
            }
        }
    }
    
    public override func viewWillAppear(_ animated: Bool) {
        // Fonts
        var fontURL = Bundle.main.url(forResource: "Muli-Bold", withExtension: "ttf")
        CTFontManagerRegisterFontsForURL(fontURL! as CFURL, CTFontManagerScope.process, nil)
        fontURL = Bundle.main.url(forResource: "Muli-SemiBold", withExtension: "ttf")
        CTFontManagerRegisterFontsForURL(fontURL! as CFURL, CTFontManagerScope.process, nil)
        
        instructionLabel.font = UIFont(name: "Muli-SemiBold", size: 18)
        person1Label.font = UIFont(name: "Muli-Bold", size: 13)
        person2Label.font = UIFont(name: "Muli-Bold", size: 13)
        person3Label.font = UIFont(name: "Muli-Bold", size: 13)
        resetButton.titleLabel?.font = UIFont(name: "Muli-Bold", size: 16)
        randomButton.titleLabel?.font = UIFont(name: "Muli-Bold", size: 16)
    }
    
    func updateUI(){
        // Shadow
        whiteView.layer.shadowColor = UIColor.black.cgColor
        whiteView.layer.shadowOpacity = 0.2
        whiteView.layer.shadowOffset = .zero
        whiteView.layer.shadowRadius = 10
        
        // Glasses
        person1GlassesImageView.alpha = products.glasses.vector[0] == 0 ? 0.2 : 1.0
        person2GlassesImageView.alpha = products.glasses.vector[1] == 0 ? 0.2 : 1.0
        person3GlassesImageView.alpha = products.glasses.vector[2] == 0 ? 0.2 : 1.0
        
        // Camera
        person1CameraImageView.alpha = products.camera.vector[0] == 0 ? 0.2 : 1.0
        person2CameraImageView.alpha = products.camera.vector[1] == 0 ? 0.2 : 1.0
        person3CameraImageView.alpha = products.camera.vector[2] == 0 ? 0.2 : 1.0
        
        // Bag
        person1BagImageView.alpha = products.bag.vector[0] == 0 ? 0.2 : 1.0
        person2BagImageView.alpha = products.bag.vector[1] == 0 ? 0.2 : 1.0
        person3BagImageView.alpha = products.bag.vector[2] == 0 ? 0.2 : 1.0
        
        // Headphones
        person1HeadphonesImageView.alpha = products.headphones.vector[0] == 0 ? 0.2 : 1.0
        person2HeadphonesImageView.alpha = products.headphones.vector[1] == 0 ? 0.2 : 1.0
        person3HeadphonesImageView.alpha = products.headphones.vector[2] == 0 ? 0.2 : 1.0
    }

    func setupUI(){
        // Drag Glasses
        dragGlassesImageView.addGestureRecognizer(UIPanGestureRecognizer(target: self, action: #selector(dragGlassesHandler(recognizer:))))
        dragGlassesImageView.isUserInteractionEnabled = true
        
        // Drag Camera
        dragCameraImageView.addGestureRecognizer(UIPanGestureRecognizer(target: self, action: #selector(dragCameraHandler(recognizer:))))
        dragCameraImageView.isUserInteractionEnabled = true

        // Drag Bag
        dragBagImageView.addGestureRecognizer(UIPanGestureRecognizer(target: self, action: #selector(dragBagHandler(recognizer:))))
        dragBagImageView.isUserInteractionEnabled = true
        
        // Drag Headphones
        dragHeadphonesImageView.addGestureRecognizer(UIPanGestureRecognizer(target: self, action: #selector(dragHeadphonesHandler(recognizer:))))
        dragHeadphonesImageView.isUserInteractionEnabled = true
    }
    
    func playSoundEffect(){
        if let player = audioPlayer{
            if player.isPlaying{
                player.pause()
            }
            player.currentTime = 0
            player.play()
        }
    }
    
    func selectBlueView(view: UIView){
        view.backgroundColor = UIColor(r: 232, g: 249, b: 253, a: 1)
    }
    
    func deselectBlueView(view: UIView){
        view.backgroundColor = UIColor(r: 234, g: 243, b: 245, a: 1)
    }
    
    func gestureIntersectsBlueViews(gestureView: CGRect, person1View: CGRect, person2View: CGRect, person3View: CGRect, itemImageView: UIImageView, item: Item){
        if gestureView.intersects(person1View){
            selectBlueView(view: person1BlueView)
            deselectBlueView(view: person2BlueView)
            deselectBlueView(view: person3BlueView)
        }else if gestureView.intersects(person2View){
            selectBlueView(view: person2BlueView)
            deselectBlueView(view: person1BlueView)
            deselectBlueView(view: person3BlueView)
        }else if gestureView.intersects(person3View){
            selectBlueView(view: person3BlueView)
            deselectBlueView(view: person1BlueView)
            deselectBlueView(view: person2BlueView)
        }else{
            deselectBlueView(view: person1BlueView)
            deselectBlueView(view: person2BlueView)
            deselectBlueView(view: person3BlueView)
        }
    }
    
    @objc func dragGlassesHandler(recognizer: UIPanGestureRecognizer){
        guard let gestureview = recognizer.view else { return }

        let gestureTop = gestureview.superview!.convert(gestureview.frame, to: self.view)
        let person1ViewTop = person1View.superview!.convert(person1View.frame, to: self.view)
        let person2ViewTop = person1View.superview!.convert(person2View.frame, to: self.view)
        let person3ViewTop = person1View.superview!.convert(person3View.frame, to: self.view)
        
        if recognizer.state == .began || recognizer.state == .changed {
            let translation = recognizer.translation(in: self.view)
            gestureview.center = CGPoint(x: gestureview.center.x + translation.x, y: gestureview.center.y + translation.y)
            recognizer.setTranslation(CGPoint.zero, in: self.view)
            
            gestureIntersectsBlueViews(gestureView: gestureTop, person1View: person1ViewTop, person2View: person2ViewTop, person3View: person3ViewTop, itemImageView: dragGlassesImageView, item: .glasses)
            
        }else{
            deselectBlueView(view: person1BlueView)
            deselectBlueView(view: person2BlueView)
            deselectBlueView(view: person3BlueView)
            
            if gestureTop.intersects(person1ViewTop){
                playSoundEffect()
                person1GlassesImageView.alpha = 1.0
                products.glasses.vector[0] = 1
            }else if gestureTop.intersects(person2ViewTop){
                playSoundEffect()
                person2GlassesImageView.alpha = 1.0
                products.glasses.vector[1] = 1
            }else if gestureTop.intersects(person3ViewTop){
                playSoundEffect()
                person3GlassesImageView.alpha = 1.0
                products.glasses.vector[2] = 1
            }
            
            UIView.animate(withDuration: 0.3) {
                gestureview.frame.origin = CGPoint(x: 0, y: 0)
            }
        }
    }
    
    @objc func dragCameraHandler(recognizer: UIPanGestureRecognizer){
        guard let gestureview = recognizer.view else { return }
        
        let gestureTop = gestureview.superview!.convert(gestureview.frame, to: self.view)
        let person1ViewTop = person1View.superview!.convert(person1View.frame, to: self.view)
        let person2ViewTop = person1View.superview!.convert(person2View.frame, to: self.view)
        let person3ViewTop = person1View.superview!.convert(person3View.frame, to: self.view)
        
        if recognizer.state == .began || recognizer.state == .changed {
            let translation = recognizer.translation(in: self.view)
            gestureview.center = CGPoint(x: gestureview.center.x + translation.x, y: gestureview.center.y + translation.y)
            recognizer.setTranslation(CGPoint.zero, in: self.view)
            
            gestureIntersectsBlueViews(gestureView: gestureTop, person1View: person1ViewTop, person2View: person2ViewTop, person3View: person3ViewTop, itemImageView: dragGlassesImageView, item: .glasses)
        }else{
            deselectBlueView(view: person1BlueView)
            deselectBlueView(view: person2BlueView)
            deselectBlueView(view: person3BlueView)
            
            if gestureTop.intersects(person1ViewTop){
                playSoundEffect()
                person1CameraImageView.alpha = 1.0
                products.camera.vector[0] = 1
            }else if gestureTop.intersects(person2ViewTop){
                playSoundEffect()
                person2CameraImageView.alpha = 1.0
                products.camera.vector[1] = 1
            }else if gestureTop.intersects(person3ViewTop){
                playSoundEffect()
                person3CameraImageView.alpha = 1.0
                products.camera.vector[2] = 1
            }
            
            let dragItemStackWith = self.dragCameraImageView.superview!.frame.width
            var x = (dragItemStackWith-(self.dragCameraImageView.frame.width*4))/3
            x += self.dragCameraImageView.frame.width
            
            UIView.animate(withDuration: 0.3) {
                
                gestureview.frame.origin = CGPoint(x: x, y: 0)
            }
        }
    }
    
    @objc func dragBagHandler(recognizer: UIPanGestureRecognizer){
        guard let gestureview = recognizer.view else { return }
        
        let gestureTop = gestureview.superview!.convert(gestureview.frame, to: self.view)
        let person1ViewTop = person1View.superview!.convert(person1View.frame, to: self.view)
        let person2ViewTop = person1View.superview!.convert(person2View.frame, to: self.view)
        let person3ViewTop = person1View.superview!.convert(person3View.frame, to: self.view)
        
        if recognizer.state == .began || recognizer.state == .changed {
            let translation = recognizer.translation(in: self.view)
            gestureview.center = CGPoint(x: gestureview.center.x + translation.x, y: gestureview.center.y + translation.y)
            recognizer.setTranslation(CGPoint.zero, in: self.view)
            
            gestureIntersectsBlueViews(gestureView: gestureTop, person1View: person1ViewTop, person2View: person2ViewTop, person3View: person3ViewTop, itemImageView: dragGlassesImageView, item: .glasses)
        }else{
            deselectBlueView(view: person1BlueView)
            deselectBlueView(view: person2BlueView)
            deselectBlueView(view: person3BlueView)
            
            let gestureTop = gestureview.superview!.convert(gestureview.frame, to: self.view)
            let person1ViewTop = person1View.superview!.convert(person1View.frame, to: self.view)
            let person2ViewTop = person1View.superview!.convert(person2View.frame, to: self.view)
            let person3ViewTop = person1View.superview!.convert(person3View.frame, to: self.view)
            
            if gestureTop.intersects(person1ViewTop){
                playSoundEffect()
                person1BagImageView.alpha = 1.0
                products.bag.vector[0] = 1
            }else if gestureTop.intersects(person2ViewTop){
                playSoundEffect()
                person2BagImageView.alpha = 1.0
                products.bag.vector[1] = 1
            }else if gestureTop.intersects(person3ViewTop){
                playSoundEffect()
                person3BagImageView.alpha = 1.0
                products.bag.vector[2] = 1
            }
            
            let dragItemStackWith = self.dragCameraImageView.superview!.frame.width
            var x = (dragItemStackWith-(self.dragCameraImageView.frame.width*4))/3
            x += self.dragCameraImageView.frame.width
            x *= 2
            
            UIView.animate(withDuration: 0.3) {
                gestureview.frame.origin = CGPoint(x: x, y: 0)
            }
        }
    }
    
    @objc func dragHeadphonesHandler(recognizer: UIPanGestureRecognizer){
        guard let gestureview = recognizer.view else { return }
        
        let gestureTop = gestureview.superview!.convert(gestureview.frame, to: self.view)
        let person1ViewTop = person1View.superview!.convert(person1View.frame, to: self.view)
        let person2ViewTop = person1View.superview!.convert(person2View.frame, to: self.view)
        let person3ViewTop = person1View.superview!.convert(person3View.frame, to: self.view)
        
        if recognizer.state == .began || recognizer.state == .changed {
            let translation = recognizer.translation(in: self.view)
            gestureview.center = CGPoint(x: gestureview.center.x + translation.x, y: gestureview.center.y + translation.y)
            recognizer.setTranslation(CGPoint.zero, in: self.view)
            
            gestureIntersectsBlueViews(gestureView: gestureTop, person1View: person1ViewTop, person2View: person2ViewTop, person3View: person3ViewTop, itemImageView: dragGlassesImageView, item: .glasses)
        }else{
            deselectBlueView(view: person1BlueView)
            deselectBlueView(view: person2BlueView)
            deselectBlueView(view: person3BlueView)
            
            let gestureTop = gestureview.superview!.convert(gestureview.frame, to: self.view)
            let person1ViewTop = person1View.superview!.convert(person1View.frame, to: self.view)
            let person2ViewTop = person1View.superview!.convert(person2View.frame, to: self.view)
            let person3ViewTop = person1View.superview!.convert(person3View.frame, to: self.view)
            
            if gestureTop.intersects(person1ViewTop){
                playSoundEffect()
                person1HeadphonesImageView.alpha = 1.0
                products.headphones.vector[0] = 1
            }else if gestureTop.intersects(person2ViewTop){
                playSoundEffect()
                person2HeadphonesImageView.alpha = 1.0
                products.headphones.vector[1] = 1
            }else if gestureTop.intersects(person3ViewTop){
                playSoundEffect()
                person3HeadphonesImageView.alpha = 1.0
                products.headphones.vector[2] = 1
            }
            
            let dragItemStackWith = self.dragCameraImageView.superview!.frame.width
            var x = (dragItemStackWith-(self.dragCameraImageView.frame.width*4))/3
            x += self.dragCameraImageView.frame.width
            x *= 3
            
            UIView.animate(withDuration: 0.3) {
                gestureview.frame.origin = CGPoint(x: x, y: 0)
            }
        }
    }
    
    
    @IBAction func resetTapped(_ sender: UIButton) {
        products.resetVectors()
        updateUI()
    }
    
    @IBAction func randomTapped(_ sender: UIButton) {
        products.randomVectors()
        playSoundEffect()
        updateUI()
    }
    

}

extension BasketVC {
    class public func loadFromStoryboard() -> UIViewController? {
        let storyboard = UIStoryboard.init(name: "Main", bundle: nil)
        return storyboard.instantiateViewController(withIdentifier: "BasketVC") as! BasketVC
    }
}

public var name = "default"

extension UIColor{
    
    convenience public init(r: CGFloat, g: CGFloat, b: CGFloat, a: CGFloat) {
        self.init(red: r/255, green: g/255, blue: b/255, alpha: a)
    }
    
    struct Login{
        static let warningRed = UIColor(r: 255, g: 90, b: 87, a: 1)
        static let seperatorGray = UIColor(r: 225, g: 225, b: 225, a: 1)
        static let darkGray = UIColor(r: 183, g: 183, b: 183, a: 1)
    }
    
}
