//
//  Product.swift
//  Book_Sources
//
//  Created by Marton Zeisler on 2019. 03. 20..
//

import Foundation

struct Glasses{
    var vector = [1,0,0]{
        didSet{
            UserDefaults.standard.setValue(vector, forKey: "glassesVector")
        }
    }
    var name = "SUNGLASSES"
    var itemImageName = "itemGlasses"
    var whiteImageName = "whiteGlasses"
    
    mutating func reset(){
        vector = [1,0,0]
    }
}

struct Camera{
    var vector = [1,0,0]{
        didSet{
            UserDefaults.standard.setValue(vector, forKey: "cameraVector")
        }
    }
    var name = "CAMEREA"
    var itemImageName = "itemCamera"
    var whiteImageName = "whiteCamera"
    
    mutating func reset(){
        vector = [0,1,0]
    }
}

struct Bag{
    var vector = [1,0,0]{
        didSet{
            UserDefaults.standard.setValue(vector, forKey: "bagVector")
        }
    }
    var name = "BACKPACK"
    var itemImageName = "itemBag"
    var whiteImageName = "whiteBag"
    
    mutating func reset(){
        vector = [0,0,1]
    }
}

struct Headphones{
    var vector = [1,0,0]{
        didSet{
            UserDefaults.standard.setValue(vector, forKey: "headphonesVector")
        }
    }
    var name = "HEADPHONES"
    var itemImageName = "itemHeadphones"
    var whiteImageName = "whiteHeadphones"
    
    mutating func reset(){
        vector = [0,0,1]
    }
}

struct Products{
    var glasses: Glasses
    var camera: Camera
    var bag: Bag
    var headphones: Headphones
    
    init() {
        glasses = Glasses()
        camera = Camera()
        bag = Bag()
        headphones = Headphones()
        
        readVectors()
    }
    
    func findLowestPair(item: Item)->(Item, Double){
        let itemVector = getSelectedItemVector(item: item)
        let (pair1, pair2, pair3) = getPairItemVectors(item: item)
        let pair1Angle = calculateAngle(vector1: itemVector, vector2: pair1.1)
        let pair2Angle = calculateAngle(vector1: itemVector, vector2: pair2.1)
        let pair3Angle = calculateAngle(vector1: itemVector, vector2: pair3.1)
        
        let smallestAngle = min(pair1Angle, pair2Angle, pair3Angle)
        
        if smallestAngle == pair1Angle{
            return (pair1.0, smallestAngle)
        }else if smallestAngle == pair2Angle{
            return (pair2.0, smallestAngle)
        }else{
            return (pair3.0, smallestAngle)
        }
    }
    
    func findBestMatchFor2Items(item1: Item, item2: Item)->(String,Item?) {
        let lowestForItem1 = findLowestPair(item: item1)
        let lowestForItem2 = findLowestPair(item: item2)
        
        if lowestForItem1.1 == 90.0 && lowestForItem2.1 == 90.0{
            return ("We couldn't find a recommendation for any of your items.", nil)
        }
        
        if item1 == lowestForItem2.0{
            // suggestion cannot be lowestItem2
            // Only possible suggestion is lowestItem1
            if lowestForItem1.1 == 90.0{
                return ("Your second item's recommendation is already in your basket and we couldn't find a recommendation for your first item.", nil)
            }else{
                return ("Your second item's recommendation is already in your basket, so the best recommendation for you to buy is your first item's match.", lowestForItem1.0)
            }
        }
        
        if item2 == lowestForItem1.0{
            // suggestion cannot be lowestItem1
            // Only possible suggestion is lowestItem2
            if lowestForItem2.1 == 90.0{
                return ("Your first item's recommendation is already in your basket and we couldn't find a recommendation for your second item.", nil)
            }else{
                return ("Your first item's recommendation is already in your basket, so the best recommendation for you to buy is your second item's match.", lowestForItem2.0)
            }
        }
        
        if lowestForItem2.1 < lowestForItem1.1{
            return ("Your second item has the best match, so therefore we recommend you to add \(lowestForItem2.0.rawValue) to your basket.", lowestForItem2.0)
        }else{
            return ("Your first item has the best match, so therefore we recommend you to add \(lowestForItem1.0.rawValue) to your basket.", lowestForItem1.0)
        }        
    }
    
    func getPairItemVectors(item: Item)->((Item, [Int]), (Item, [Int]), (Item, [Int])){
        if item == .glasses{
            return ((.camera, camera.vector), (.bag, bag.vector), (.headphones, headphones.vector))
        }else if item == .camera{
            return ((.glasses ,glasses.vector), (.bag ,bag.vector), (.headphones, headphones.vector))
        }else if item == .bag{
            return ((.glasses, glasses.vector), (.camera, camera.vector), (.headphones, headphones.vector))
        }else{
            return ((.glasses, glasses.vector), (.camera, camera.vector), (.bag, bag.vector))
        }
    }
    
    func getPairItemAngles(item: Item)->((Item, Double), (Item, Double), (Item, Double)){
        let itemVector = getSelectedItemVector(item: item)
        let (pair1, pair2, pair3) = getPairItemVectors(item: item)
        
        let pair1Vector = getSelectedItemVector(item: pair1.0)
        let pair2Vector = getSelectedItemVector(item: pair2.0)
        let pair3Vector = getSelectedItemVector(item: pair3.0)
        
        let pair1Angle = calculateAngle(vector1: itemVector, vector2: pair1Vector)
        let pair2Angle = calculateAngle(vector1: itemVector, vector2: pair2Vector)
        let pair3Angle = calculateAngle(vector1: itemVector, vector2: pair3Vector)
        
        return ((pair1.0, pair1Angle), (pair2.0, pair2Angle), (pair3.0, pair3Angle))
    }
    
    func getSelectedItemVector(item: Item)->[Int]{
        if item == .glasses{
            return glasses.vector
        }else if item == .camera{
            return camera.vector
        }else if item == .bag{
            return bag.vector
        }else{
            return headphones.vector
        }
    }
    
    func calculateAngle(vector1: [Int], vector2: [Int])->Double{
        if vector1.count != vector2.count{
            return 0
        }
        
        var scalarProduct = 0.0
        var vector1Length = 0.0
        var vector2Length = 0.0
        for index in 0..<vector1.count{
            scalarProduct += Double((vector1[index]*vector2[index]))
            vector1Length += (pow(Double(vector1[index]), 2.0))
            vector2Length += (pow(Double(vector2[index]), 2.0))
        }
        
        let vectorLengthsProduct = sqrt(vector1Length*vector2Length)
        let angleRadian = acos(scalarProduct/vectorLengthsProduct)
        let angleDegrees = rad2deg(angleRadian)
        return angleDegrees
    }
    
    func rad2deg(_ number: Double) -> Double {
        return number * 180 / .pi
    }
    
    mutating func readVectors(){
        if let vector = UserDefaults.standard.value(forKey: "glassesVector") as? [Int]{
            glasses.vector = vector
        }else{
            glasses.reset()
        }
        
        if let vector = UserDefaults.standard.value(forKey: "cameraVector") as? [Int]{
            camera.vector = vector
        }else{
            camera.reset()
        }
        
        if let vector = UserDefaults.standard.value(forKey: "bagVector") as? [Int]{
            bag.vector = vector
        }else{
            bag.reset()
        }
        
        if let vector = UserDefaults.standard.value(forKey: "headphonesVector") as? [Int]{
            headphones.vector = vector
        }else{
            headphones.reset()
        }
    }
    
    mutating func resetVectors(){
        glasses.reset()
        camera.reset()
        bag.reset()
        headphones.reset()
    }
    
    mutating func randomVectors(){
        // Glasses
        glasses.vector[0] = Int.random(in: 0...1)
        glasses.vector[1] = Int.random(in: 0...1)
        glasses.vector[2] = Int.random(in: 0...1)
        
        // Camera
        camera.vector[0] = Int.random(in: 0...1)
        camera.vector[1] = Int.random(in: 0...1)
        camera.vector[2] = Int.random(in: 0...1)
        
        // Bag
        bag.vector[0] = Int.random(in: 0...1)
        bag.vector[1] = Int.random(in: 0...1)
        bag.vector[2] = Int.random(in: 0...1)
        
        // Headphones
        headphones.vector[0] = Int.random(in: 0...1)
        headphones.vector[1] = Int.random(in: 0...1)
        headphones.vector[2] = Int.random(in: 0...1)
        
        if glasses.vector == [0,0,0]{
            glasses.reset()
        }
        
        if camera.vector == [0,0,0]{
            camera.reset()
        }
        
        if bag.vector == [0,0,0]{
            bag.reset()
        }
        
        if headphones.vector == [0,0,0]{
            headphones.reset()
        }
    }
    
}

enum Item: String{
    case glasses = "SUNGLASSES"
    case camera = "CAMERA"
    case bag = "BACKPACK"
    case headphones = "HEADPHONES"
    case none
    
    func getWhiteImage()->String{
        if self == .glasses{
            return "whiteGlasses"
        }else if self == .camera{
            return "whiteCamera"
        }else if self == .bag{
            return "whiteBag"
        }else{
            return "whiteHeadphones"
        }
    }
    
    func getItemImage()->String{
        if self == .glasses{
            return "glasses"
        }else if self == .camera{
            return "camera"
        }else if self == .bag{
            return "bag"
        }else{
            return "headphones"
        }
    }
    
}
