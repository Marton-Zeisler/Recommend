//
//  Step1View.swift
//  Book_Sources
//
//  Created by Marton Zeisler on 2019. 03. 18..
//

import UIKit

class Step1View: UIView {
    
    @IBOutlet var contentView: UIView!
    
    @IBOutlet var stepLabel: UILabel!
    @IBOutlet weak var stackView: UIStackView!
    @IBOutlet weak var getButton: UIButton!
    @IBOutlet weak var continueButton: UIButton!
    
    @IBOutlet var titleLabel: UILabel!
    
    @IBOutlet var itemImageView: UIImageView!
    
    @IBOutlet var person1: UIImageView!
    @IBOutlet var tick1: UIImageView!
    
    @IBOutlet var person2: UIImageView!
    @IBOutlet var tick2: UIImageView!
    
    @IBOutlet var person3: UIImageView!
    @IBOutlet var tick3: UIImageView!
    
    @IBOutlet var vectorLabel: UILabel!
    
    weak var stepViewDelegate: StepViewDelegate?
    
    @IBOutlet var whiteView: UIView!
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setups()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        setups()
    }
    
    func setups(){
        let nib = UINib(nibName: "Step1View", bundle: .main)
        nib.instantiate(withOwner: self, options: nil)
        
        self.addSubview(self.contentView)
        self.contentView.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            self.contentView.topAnchor.constraint(equalTo: self.topAnchor),
            self.contentView.bottomAnchor.constraint(equalTo: self.bottomAnchor),
            self.contentView.leadingAnchor.constraint(equalTo: self.leadingAnchor),
            self.contentView.trailingAnchor.constraint(equalTo: self.trailingAnchor),
            ])
        
        // Shadow
        whiteView.layer.shadowColor = UIColor.black.cgColor
        whiteView.layer.shadowOpacity = 0.2
        whiteView.layer.shadowOffset = .zero
        whiteView.layer.shadowRadius = 10
        
        // Font
        var fontURL = Bundle.main.url(forResource: "Muli-Bold", withExtension: "ttf")
        CTFontManagerRegisterFontsForURL(fontURL! as CFURL, CTFontManagerScope.process, nil)
        fontURL = Bundle.main.url(forResource: "Muli-SemiBold", withExtension: "ttf")
        CTFontManagerRegisterFontsForURL(fontURL! as CFURL, CTFontManagerScope.process, nil)
        
        stepLabel.font = UIFont(name: "Muli-Bold", size: 18)
        titleLabel.font = UIFont(name: "Muli-SemiBold", size: 16)
        getButton.titleLabel?.font = UIFont(name: "Muli-Bold", size: 16)
        vectorLabel.font = UIFont(name: "Muli-Bold", size: 16)
        continueButton.titleLabel?.font = UIFont(name: "Muli-Bold", size: 16)
    }
    
    func setupUI(selectedItem: Item, selectedVector: [Int]){
        if selectedItem == .glasses || selectedItem == .headphones{
            titleLabel.text = "\(selectedItem.rawValue)' VECTOR"
            getButton.setTitle("GET \(selectedItem.rawValue)' VECTOR", for: .normal)
        }else{
            titleLabel.text = "\(selectedItem.rawValue)'s VECTOR"
            getButton.setTitle("GET \(selectedItem.rawValue)'s VECTOR", for: .normal)
        }
        
        itemImageView.image = UIImage(named: selectedItem.getWhiteImage())
        
        if selectedVector[0] == 0{
            person1.alpha = 0.2
            tick1.image = UIImage(named: "redCross")
        }else{
            person1.alpha = 1
            tick1.image = UIImage(named: "blueTick")
        }
        
        if selectedVector[1] == 0{
            person2.alpha = 0.2
            tick2.image = UIImage(named: "redCross")
        }else{
            person2.alpha = 1
            tick2.image = UIImage(named: "blueTick")
        }
        
        if selectedVector[2] == 0{
            person3.alpha = 0.2
            tick3.image = UIImage(named: "redCross")
        }else{
            person3.alpha = 1
            tick3.image = UIImage(named: "blueTick")
        }
        
        
        vectorLabel.text = "= (\(selectedVector[0]), \(selectedVector[1]), \(selectedVector[2]))"
    }
    
    
    @IBAction func getTapped(_ sender: Any) {
        getButton.isHidden = true
        stackView.isHidden = false
        continueButton.isHidden = false
    }
    
    @IBAction func continueTapped(_ sender: Any) {
        stepViewDelegate?.nextTapped()
    }
    
    
}

protocol StepViewDelegate: class{
    func nextTapped()
}
