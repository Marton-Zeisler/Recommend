//
//  FilteringTableVC.swift
//  Book_Sources
//
//  Created by Marton Zeisler on 2019. 03. 17..
//

import UIKit

public class FilteringTableVC: UIViewController {

    @IBOutlet var whiteView: UIView!
    
    @IBOutlet weak var label: UILabel!
    
    // Glasses People
    @IBOutlet var glassesPerson1: UIImageView!
    @IBOutlet var glassesTick1: UIImageView!
    @IBOutlet var glassesPerson2: UIImageView!
    @IBOutlet var glassesTick2: UIImageView!
    @IBOutlet var glassesPerson3: UIImageView!
    @IBOutlet var glassesTick3: UIImageView!
    
    // Camera People
    @IBOutlet var cameraPerson1: UIImageView!
    @IBOutlet var cameraTick1: UIImageView!
    @IBOutlet var cameraPerson2: UIImageView!
    @IBOutlet var cameraTick2: UIImageView!
    @IBOutlet var cameraPerson3: UIImageView!
    @IBOutlet var cameraTick3: UIImageView!
    
    // Bag People
    @IBOutlet var bagPerson1: UIImageView!
    @IBOutlet var bagTick1: UIImageView!
    @IBOutlet var bagPerson2: UIImageView!
    @IBOutlet var bagTick2: UIImageView!
    @IBOutlet var bagPerson3: UIImageView!
    @IBOutlet var bagTick3: UIImageView!
    
    // Headphones People
    @IBOutlet var headphonesPerson1: UIImageView!
    @IBOutlet var headphonesTick1: UIImageView!
    @IBOutlet var headphonesPerson2: UIImageView!
    @IBOutlet var headphonesTick2: UIImageView!
    @IBOutlet var headphonesPerson3: UIImageView!
    @IBOutlet var headphonesTick3: UIImageView!
    
    @IBOutlet var instructionLabel: UILabel!
    @IBOutlet var showButton: UIButton!
    
    var products = Products()
    
    override public func viewDidLoad() {
        super.viewDidLoad()
        
        updateUI()
    }
    
    public override func viewWillAppear(_ animated: Bool) {
        var fontURL = Bundle.main.url(forResource: "Muli-Bold", withExtension: "ttf")
        CTFontManagerRegisterFontsForURL(fontURL! as CFURL, CTFontManagerScope.process, nil)
        fontURL = Bundle.main.url(forResource: "Muli-SemiBold", withExtension: "ttf")
        CTFontManagerRegisterFontsForURL(fontURL! as CFURL, CTFontManagerScope.process, nil)
        
        instructionLabel.font = UIFont(name: "Muli-SemiBold", size: 22)
        showButton.titleLabel?.font = UIFont(name: "Muli-Bold", size: 16)
    }
    
    
    func updateUI(){
        // Shadow
        whiteView.layer.shadowColor = UIColor.black.cgColor
        whiteView.layer.shadowOpacity = 0.2
        whiteView.layer.shadowOffset = .zero
        whiteView.layer.shadowRadius = 10
        
        
        // Glasses
        if products.glasses.vector[0] == 0{
            glassesPerson1.alpha = 0.2
            glassesTick1.image = UIImage(named: "redCross")
        }else{
            glassesPerson1.alpha = 1
            glassesTick1.image = UIImage(named: "blueTick")
        }
        
        if products.glasses.vector[1] == 0{
            glassesPerson2.alpha = 0.2
            glassesTick2.image = UIImage(named: "redCross")
        }else{
            glassesPerson2.alpha = 1
            glassesTick2.image = UIImage(named: "blueTick")
        }
        
        if products.glasses.vector[2] == 0{
            glassesPerson3.alpha = 0.2
            glassesTick3.image = UIImage(named: "redCross")
        }else{
            glassesPerson3.alpha = 1
            glassesTick3.image = UIImage(named: "blueTick")
        }
        
        // Camera
        if products.camera.vector[0] == 0{
            cameraPerson1.alpha = 0.2
            cameraTick1.image = UIImage(named: "redCross")
        }else{
            cameraPerson1.alpha = 1
            cameraTick1.image = UIImage(named: "blueTick")
        }
        
        if products.camera.vector[1] == 0{
            cameraPerson2.alpha = 0.2
            cameraTick2.image = UIImage(named: "redCross")
        }else{
            cameraPerson2.alpha = 1
            cameraTick2.image = UIImage(named: "blueTick")
        }
        
        if products.camera.vector[2] == 0{
            cameraPerson3.alpha = 0.2
            cameraTick3.image = UIImage(named: "redCross")
        }else{
            cameraPerson3.alpha = 1
            cameraTick3.image = UIImage(named: "blueTick")
        }
        
        // Bag
        if products.bag.vector[0] == 0{
            bagPerson1.alpha = 0.2
            bagTick1.image = UIImage(named: "redCross")
        }else{
            bagPerson1.alpha = 1
            bagTick1.image = UIImage(named: "blueTick")
        }
        
        if products.bag.vector[1] == 0{
            bagPerson2.alpha = 0.2
            bagTick2.image = UIImage(named: "redCross")
        }else{
            bagPerson2.alpha = 1
            bagTick2.image = UIImage(named: "blueTick")
        }
        
        if products.bag.vector[2] == 0{
            bagPerson3.alpha = 0.2
            bagTick3.image = UIImage(named: "redCross")
        }else{
            bagPerson3.alpha = 1
            bagTick3.image = UIImage(named: "blueTick")
        }
        
        // Headphones
        if products.headphones.vector[0] == 0{
            headphonesPerson1.alpha = 0.2
            headphonesTick1.image = UIImage(named: "redCross")
        }else{
            headphonesPerson1.alpha = 1
            headphonesTick1.image = UIImage(named: "blueTick")
        }
        
        if products.headphones.vector[1] == 0{
            headphonesPerson2.alpha = 0.2
            headphonesTick2.image = UIImage(named: "redCross")
        }else{
            headphonesPerson2.alpha = 1
            headphonesTick2.image = UIImage(named: "blueTick")
        }
        
        if products.headphones.vector[2] == 0{
            headphonesPerson3.alpha = 0.2
            headphonesTick3.image = UIImage(named: "redCross")
        }else{
            headphonesPerson3.alpha = 1
            headphonesTick3.image = UIImage(named: "blueTick")
        }
    }
    
    @IBAction func showTapped(_ sender: Any) {
        performSegue(withIdentifier: "showSegue", sender: nil)
    }
    
    public override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "showSegue"{
            let destinationVC = segue.destination as! FilteringVectorsVC
            destinationVC.products = products
        }
    }

}

extension FilteringTableVC {
    class public func loadFromStoryboard() -> UIViewController? {
        let storyboard = UIStoryboard.init(name: "Main", bundle: nil)
        return storyboard.instantiateViewController(withIdentifier: "FilteringTableVC") as! FilteringTableVC
    }
}
