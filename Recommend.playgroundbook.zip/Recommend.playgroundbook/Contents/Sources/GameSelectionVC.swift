//
//  GameSelectionVC.swift
//  Book_Sources
//
//  Created by Marton Zeisler on 2019. 03. 17..
//

import UIKit

public class GameSelectionVC: UIViewController {
    
    @IBOutlet var whiteView: UIView!
    
    @IBOutlet weak var glassesButton: UIButton!
    @IBOutlet weak var cameraButton: UIButton!
    @IBOutlet weak var bagButton: UIButton!
    @IBOutlet weak var headphonesButton: UIButton!
    
    @IBOutlet weak var glassesTick: UIImageView!
    @IBOutlet weak var cameraTick: UIImageView!
    @IBOutlet weak var bagTick: UIImageView!
    @IBOutlet weak var headphonesTick: UIImageView!
    
    var selectedItems: [(UIButton, UIImageView, Item)] = []

    @IBOutlet var instructionLabel: UILabel!
    
    @IBOutlet var showButton: UIButton!
    
    override public func viewDidLoad() {
        super.viewDidLoad()
        
        // Shadow
        whiteView.layer.shadowColor = UIColor.black.cgColor
        whiteView.layer.shadowOpacity = 0.2
        whiteView.layer.shadowOffset = .zero
        whiteView.layer.shadowRadius = 10
    }
    
    public override func viewWillAppear(_ animated: Bool) {
        var fontURL = Bundle.main.url(forResource: "Muli-Bold", withExtension: "ttf")
        CTFontManagerRegisterFontsForURL(fontURL! as CFURL, CTFontManagerScope.process, nil)
        fontURL = Bundle.main.url(forResource: "Muli-SemiBold", withExtension: "ttf")
        CTFontManagerRegisterFontsForURL(fontURL! as CFURL, CTFontManagerScope.process, nil)
        
        instructionLabel.font = UIFont(name: "Muli-SemiBold", size: 19)
        showButton.titleLabel?.font = UIFont(name: "Muli-Bold", size: 16)
    }
    
    @IBAction func glassesTapped(_ sender: Any) {
        if !glassesTick.isHidden{
            glassesTick.isHidden = true
            glassesButton.setImage(UIImage(imageLiteralResourceName: "hiddenGlasses.png"), for: .normal)
            removeButton(button: glassesButton)
            return
        }
        
        if selectedItems.count >= 2{
            let removed = selectedItems.removeFirst()
            hideButton(button: removed.0)
            removed.1.isHidden = true
        }
        
        selectedItems.append((glassesButton, glassesTick, .glasses))
        glassesButton.setImage(UIImage(imageLiteralResourceName: "itemGlasses.png"), for: .normal)
        glassesTick.isHidden = false
    }
    
    @IBAction func cameraTapped(_ sender: Any) {
        if !cameraTick.isHidden{
            cameraTick.isHidden = true
            cameraButton.setImage(UIImage(imageLiteralResourceName: "hiddenCamera.png"), for: .normal)
            removeButton(button: cameraButton)
            return
        }
        
        if selectedItems.count >= 2{
            let removed = selectedItems.removeFirst()
            hideButton(button: removed.0)
            removed.1.isHidden = true
        }
        
        selectedItems.append((cameraButton, cameraTick, .camera))
        cameraButton.setImage(UIImage(imageLiteralResourceName: "itemCamera.png"), for: .normal)
        cameraTick.isHidden = false
    }
    
    @IBAction func bagTapped(_ sender: Any) {
        if !bagTick.isHidden{
            bagTick.isHidden = true
            bagButton.setImage(UIImage(imageLiteralResourceName: "hiddenBag.png"), for: .normal)
            removeButton(button: bagButton)
            return
        }
        
        if selectedItems.count >= 2{
            let removed = selectedItems.removeFirst()
            hideButton(button: removed.0)
            removed.1.isHidden = true
        }
        
        selectedItems.append((bagButton, bagTick, .bag))
        bagButton.setImage(UIImage(imageLiteralResourceName: "itemBag.png"), for: .normal)
        bagTick.isHidden = false
    }
    
    @IBAction func headphonesTapped(_ sender: Any) {
        if !headphonesTick.isHidden{
            headphonesTick.isHidden = true
            headphonesButton.setImage(UIImage(imageLiteralResourceName: "hiddenHeadphones.png"), for: .normal)
            removeButton(button: headphonesButton)
            return
        }
        
        if selectedItems.count >= 2{
            let removed = selectedItems.removeFirst()
            hideButton(button: removed.0)
            removed.1.isHidden = true
        }
        
        selectedItems.append((headphonesButton, headphonesTick, .headphones))
        headphonesButton.setImage(UIImage(imageLiteralResourceName: "itemHeadphones.png"), for: .normal)
        headphonesTick.isHidden = false
    }
    
    func hideButton(button: UIButton){
        if button == glassesButton{
            glassesButton.setImage(UIImage(imageLiteralResourceName: "hiddenGlasses.png"), for: .normal)
        }else if button == cameraButton{
            cameraButton.setImage(UIImage(imageLiteralResourceName: "hiddenCamera.png"), for: .normal)
        }else if button == bagButton{
            bagButton.setImage(UIImage(imageLiteralResourceName: "hiddenBag.png"), for: .normal)
        }else if button == headphonesButton{
            headphonesButton.setImage(UIImage(imageLiteralResourceName: "hiddenHeadphones.png"), for: .normal)
        }
    }
    
    func removeButton(button: UIButton){
        for index in 0..<selectedItems.count{
            if selectedItems[index].0 == button{
                selectedItems.remove(at: index)
                return
            }
        }
    }
    
    @IBAction func seeTapped(_ sender: Any) {
        if selectedItems.count == 1 || selectedItems.count == 2{
            performSegue(withIdentifier: "showSegue", sender: nil)
        }
    }
    
    public override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "showSegue"{
            let destination = segue.destination as! GameRecommendationVC
            
            if selectedItems.count == 1{
                destination.selected1Item = selectedItems[0].2
            }else if selectedItems.count == 2{
                destination.selected1Item = selectedItems[0].2
                destination.selected2Item = selectedItems[1].2
            }
        }
    }
}



extension GameSelectionVC {
    class public func loadFromStoryboard() -> UIViewController? {
        let storyboard = UIStoryboard.init(name: "Main", bundle: nil)
        return storyboard.instantiateViewController(withIdentifier: "GameSelectionVC") as! GameSelectionVC
    }
}
