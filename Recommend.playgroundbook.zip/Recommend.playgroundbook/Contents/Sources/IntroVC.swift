//
//  IntroVC.swift
//  Book_Sources
//
//  Created by Marton Zeisler on 2019. 03. 23..
//

import UIKit
import AVFoundation

public class IntroVC: UIViewController {
    
    var audioPlayer: AVAudioPlayer?

    override public func viewDidLoad() {
        super.viewDidLoad()
        
        if let path = Bundle.main.path(forResource: "introMusic.mp3", ofType: nil){
            let url = URL(fileURLWithPath: path)
            do{
                audioPlayer = try AVAudioPlayer(contentsOf: url)
                audioPlayer?.volume = 0.3
                audioPlayer?.numberOfLoops = -1
                audioPlayer?.play()
            }catch{
                //
            }
        }
    }
    
    public override func viewWillDisappear(_ animated: Bool) {
        audioPlayer?.stop()
    }
    
}

extension IntroVC {
    class public func loadFromStoryboard() -> UIViewController? {
        let storyboard = UIStoryboard.init(name: "Main", bundle: nil)
        return storyboard.instantiateViewController(withIdentifier: "IntroVC") as! IntroVC
    }
}
