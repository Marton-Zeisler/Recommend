//
//  Step4View.swift
//  Book_Sources
//
//  Created by Marton Zeisler on 2019. 03. 18..
//

import UIKit

class Step4View: UIView{
    
    @IBOutlet var whiteView: UIView!
    
    @IBOutlet var contentView: UIView!
    @IBOutlet var recommendView: UIView!
    @IBOutlet var findButton: UIButton!
    @IBOutlet var stackView: UIStackView!
    @IBOutlet var heightConstraint: NSLayoutConstraint!
    
    @IBOutlet var selectedItem: UIImageView!
    @IBOutlet var lowestItem: UIImageView!
    @IBOutlet var angle: UILabel!
    
    @IBOutlet var lowestAngleLabel: UILabel!
    @IBOutlet var pairLabel: UILabel!
    
    @IBOutlet var stepLabel: UILabel!
    @IBOutlet var titleLabel: UILabel!
    @IBOutlet var vsLabel: UILabel!
    @IBOutlet var bestLabel: UILabel!
    
    @IBOutlet var recommendImageView: UIImageView!
    @IBOutlet var recommendLabel: UILabel!
    
    @IBOutlet var recommendStack: UIStackView!
    
    @IBOutlet var noMatchLabel: UILabel!
    
    
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setups()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        setups()
    }
    
    func setups(){
        let nib = UINib(nibName: "Step4View", bundle: .main)
        nib.instantiate(withOwner: self, options: nil)
        
        self.addSubview(self.contentView)
        self.contentView.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            self.contentView.topAnchor.constraint(equalTo: self.topAnchor),
            self.contentView.bottomAnchor.constraint(equalTo: self.bottomAnchor),
            self.contentView.leadingAnchor.constraint(equalTo: self.leadingAnchor),
            self.contentView.trailingAnchor.constraint(equalTo: self.trailingAnchor),
            ])
        
        // Shadow
        whiteView.layer.shadowColor = UIColor.black.cgColor
        whiteView.layer.shadowOpacity = 0.2
        whiteView.layer.shadowOffset = .zero
        whiteView.layer.shadowRadius = 10
        
        recommendView.layer.shadowColor = UIColor.black.cgColor
        recommendView.layer.shadowOpacity = 0.2
        recommendView.layer.shadowOffset = .zero
        recommendView.layer.shadowRadius = 10
        
        // Font
        var fontURL = Bundle.main.url(forResource: "Muli-Bold", withExtension: "ttf")
        CTFontManagerRegisterFontsForURL(fontURL! as CFURL, CTFontManagerScope.process, nil)
        fontURL = Bundle.main.url(forResource: "Muli-SemiBold", withExtension: "ttf")
        CTFontManagerRegisterFontsForURL(fontURL! as CFURL, CTFontManagerScope.process, nil)
        
        stepLabel.font = UIFont(name: "Muli-Bold", size: 18)
        titleLabel.font = UIFont(name: "Muli-SemiBold", size: 15)
        vsLabel.font = UIFont(name: "Muli-Bold", size: 15)
        angle.font = UIFont(name: "Muli-Bold", size: 22)
        lowestAngleLabel.font = UIFont(name: "Muli-SemiBold", size: 16)
        pairLabel.font = UIFont(name: "Muli-SemiBold", size: 16)
        bestLabel.font = UIFont(name: "Muli-Bold", size: 14)
        recommendLabel.font = UIFont(name: "Muli-Bold", size: 13)
        
    }
    
    func setupUI(selectedItem: Item, lowestItem: Item, lowestAngle: Double){
        self.selectedItem.image = UIImage(named: selectedItem.getWhiteImage())
        self.lowestItem.image = UIImage(named: lowestItem.getWhiteImage())
        angle.text = "\(Int(round(lowestAngle)))" + "°" + " [\(Int(abs(((lowestAngle-90)/90) * 100)))% MATCH]"
        
        
        if lowestAngle == 90.0{
            recommendStack.isHidden = true
            noMatchLabel.isHidden = false
            
            lowestAngleLabel.text = "We couldn't find a match for your item"
            pairLabel.text = "A 90° degrees angle indicates no similarity between your item and your match"
        }else{
            lowestAngleLabel.text = "Lowest angle: \(Int(round(lowestAngle))) °"
            pairLabel.text = "\(selectedItem.rawValue) and \(lowestItem.rawValue) are matched with a \(Int(abs(((lowestAngle-90)/90) * 100)))% match value"
            
            recommendImageView.image = UIImage(named: lowestItem.getItemImage())
            recommendLabel.text = lowestItem.rawValue
        }
    }
    
    @IBAction func findTapped(_ sender: Any) {
        heightConstraint.isActive = false
        findButton.isHidden = true
        stackView.isHidden = false
        recommendView.isHidden = false
    }
    
    
}
