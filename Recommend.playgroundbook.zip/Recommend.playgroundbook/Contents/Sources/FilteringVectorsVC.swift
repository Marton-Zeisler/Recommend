//
//  FilteringVectorsVC.swift
//  Book_Sources
//
//  Created by Marton Zeisler on 2019. 03. 18..
//

import UIKit

public class FilteringVectorsVC: UIViewController {
    
    @IBOutlet var glasseslabel: UILabel!
    @IBOutlet var cameraLabel: UILabel!
    @IBOutlet var bagLabel: UILabel!
    @IBOutlet var headphonesLabel: UILabel!

    @IBOutlet var hideButton: UIButton!
    @IBOutlet var instructionLabel: UILabel!
    
    var products: Products!
    
    override public func viewDidLoad() {
        super.viewDidLoad()
        
        if products != nil{
            updateUI()
        }
    }
    
    public override func viewWillAppear(_ animated: Bool) {
        var fontURL = Bundle.main.url(forResource: "Muli-Bold", withExtension: "ttf")
        CTFontManagerRegisterFontsForURL(fontURL! as CFURL, CTFontManagerScope.process, nil)
        fontURL = Bundle.main.url(forResource: "Muli-SemiBold", withExtension: "ttf")
        CTFontManagerRegisterFontsForURL(fontURL! as CFURL, CTFontManagerScope.process, nil)
        
        hideButton.titleLabel?.font = UIFont(name: "Muli-Bold", size: 16)
        instructionLabel.font = UIFont(name: "Muli-SemiBold", size: 22)
        glasseslabel.font = UIFont(name: "Muli-SemiBold", size: 70)
        cameraLabel.font = UIFont(name: "Muli-SemiBold", size: 70)
        bagLabel.font = UIFont(name: "Muli-SemiBold", size: 70)
        headphonesLabel.font = UIFont(name: "Muli-SemiBold", size: 70)
    }
    
    func updateUI(){
        glasseslabel.text = "= (\(products.glasses.vector[0]), \(products.glasses.vector[1]), \(products.glasses.vector[2]))"
        cameraLabel.text = "= (\(products.camera.vector[0]), \(products.camera.vector[1]), \(products.camera.vector[2]))"
        bagLabel.text = "= (\(products.bag.vector[0]), \(products.bag.vector[1]), \(products.bag.vector[2]))"
        headphonesLabel.text = "= (\(products.headphones.vector[0]), \(products.headphones.vector[1]), \(products.headphones.vector[2]))"
    }
    
    @IBAction func hideTapped(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    

}

extension FilteringVectorsVC {
    class public func loadFromStoryboard() -> UIViewController? {
        let storyboard = UIStoryboard.init(name: "Main", bundle: nil)
        return storyboard.instantiateViewController(withIdentifier: "FilteringVectorsVC") as! FilteringVectorsVC
    }
}
