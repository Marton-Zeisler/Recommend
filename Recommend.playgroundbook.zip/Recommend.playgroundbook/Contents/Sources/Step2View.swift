//
//  Step2View.swift
//  Book_Sources
//
//  Created by Marton Zeisler on 2019. 03. 18..
//

import UIKit

class Step2View: UIView {
    
    @IBOutlet var contentView: UIView!
    
    @IBOutlet var heightConstraint: NSLayoutConstraint!
    @IBOutlet weak var getButton: UIButton!
    @IBOutlet weak var continueButton: UIButton!
    @IBOutlet weak var stackView: UIStackView!
    
    weak var stepViewDelegate: StepViewDelegate?
    
    // Item 1
    @IBOutlet var item1: UIImageView!
    @IBOutlet var item1Person1: UIImageView!
    @IBOutlet var item1Tick1: UIImageView!
    @IBOutlet var item1Person2: UIImageView!
    @IBOutlet var item1Tick2: UIImageView!
    @IBOutlet var item1Person3: UIImageView!
    @IBOutlet var item1Tick3: UIImageView!
    @IBOutlet var item1Vector: UILabel!
    
    // Item 2
    @IBOutlet var item2: UIImageView!
    @IBOutlet var item2Person1: UIImageView!
    @IBOutlet var item2Tick1: UIImageView!
    @IBOutlet var item2Person2: UIImageView!
    @IBOutlet var item2Tick2: UIImageView!
    @IBOutlet var item2Person3: UIImageView!
    @IBOutlet var item2Tick3: UIImageView!
    @IBOutlet var item2Vector: UILabel!
    
    // Item 3
    @IBOutlet var item3: UIImageView!
    @IBOutlet var item3Person1: UIImageView!
    @IBOutlet var item3Tick1: UIImageView!
    @IBOutlet var item3Person2: UIImageView!
    @IBOutlet var item3Tick2: UIImageView!
    @IBOutlet var item3Person3: UIImageView!
    @IBOutlet var item3Tick3: UIImageView!
    @IBOutlet var item3Vector: UILabel!
    
    @IBOutlet var step2Label: UILabel!
    @IBOutlet var titleLabel: UILabel!
    
    @IBOutlet var whiteView: UIView!
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setups()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        setups()
    }
    
    func setups(){
        let nib = UINib(nibName: "Step2View", bundle: .main)
        nib.instantiate(withOwner: self, options: nil)
        
        self.addSubview(self.contentView)
        self.contentView.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            self.contentView.topAnchor.constraint(equalTo: self.topAnchor),
            self.contentView.bottomAnchor.constraint(equalTo: self.bottomAnchor),
            self.contentView.leadingAnchor.constraint(equalTo: self.leadingAnchor),
            self.contentView.trailingAnchor.constraint(equalTo: self.trailingAnchor),
            ])
        
        // Shadow
        whiteView.layer.shadowColor = UIColor.black.cgColor
        whiteView.layer.shadowOpacity = 0.2
        whiteView.layer.shadowOffset = .zero
        whiteView.layer.shadowRadius = 10
        
        // Font
        var fontURL = Bundle.main.url(forResource: "Muli-Bold", withExtension: "ttf")
        CTFontManagerRegisterFontsForURL(fontURL! as CFURL, CTFontManagerScope.process, nil)
        fontURL = Bundle.main.url(forResource: "Muli-SemiBold", withExtension: "ttf")
        CTFontManagerRegisterFontsForURL(fontURL! as CFURL, CTFontManagerScope.process, nil)
        
        step2Label.font = UIFont(name: "Muli-Bold", size: 18)
        titleLabel.font = UIFont(name: "Muli-SemiBold", size: 16)
        getButton.titleLabel?.font = UIFont(name: "Muli-Bold", size: 16)
        item1Vector.font = UIFont(name: "Muli-Bold", size: 22)
        item2Vector.font = UIFont(name: "Muli-Bold", size: 22)
        item3Vector.font = UIFont(name: "Muli-Bold", size: 22)
        continueButton.titleLabel?.font = UIFont(name: "Muli-Bold", size: 16)
    }
    
    func setupUI(selectedItem: Item, item1Vector: [Int], item2Vector: [Int], item3Vector: [Int]){
        if selectedItem == .glasses{
            item1.image = UIImage(named: "whiteCamera")
            item2.image = UIImage(named: "whiteBag")
            item3.image = UIImage(named: "whiteHeadphones")
        }else if selectedItem == .camera{
            item1.image = UIImage(named: "whiteGlasses")
            item2.image = UIImage(named: "whiteBag")
            item3.image = UIImage(named: "whiteHeadphones")
        }else if selectedItem == .bag{
            item1.image = UIImage(named: "whiteGlasses")
            item2.image = UIImage(named: "whiteCamera")
            item3.image = UIImage(named: "whiteHeadphones")
        }else if selectedItem == .headphones{
            item1.image = UIImage(named: "whiteGlasses")
            item2.image = UIImage(named: "whiteCamera")
            item3.image = UIImage(named: "whiteBag")
        }
        
        // Item 1 Vector
        if item1Vector[0] == 0{
            item1Person1.alpha = 0.2
            item1Tick1.image = UIImage(named: "redCross")
        }else{
            item1Person1.alpha = 1
            item1Tick1.image = UIImage(named: "blueTick")
        }
        
        if item1Vector[1] == 0{
            item1Person2.alpha = 0.2
            item1Tick2.image = UIImage(named: "redCross")
        }else{
            item1Person2.alpha = 1
            item1Tick2.image = UIImage(named: "blueTick")
        }
        
        if item1Vector[2] == 0{
            item1Person3.alpha = 0.2
            item1Tick3.image = UIImage(named: "redCross")
        }else{
            item1Person3.alpha = 1
            item1Tick3.image = UIImage(named: "blueTick")
        }
        
        self.item1Vector.text = "= (\(item1Vector[0]), \(item1Vector[1]), \(item1Vector[2]))"
        
        
        // Item 2 Vector
        if item2Vector[0] == 0{
            item2Person1.alpha = 0.2
            item2Tick1.image = UIImage(named: "redCross")
        }else{
            item2Person1.alpha = 1
            item2Tick1.image = UIImage(named: "blueTick")
        }
        
        if item2Vector[1] == 0{
            item2Person2.alpha = 0.2
            item2Tick2.image = UIImage(named: "redCross")
        }else{
            item2Person2.alpha = 1
            item2Tick2.image = UIImage(named: "blueTick")
        }
        
        if item2Vector[2] == 0{
            item2Person3.alpha = 0.2
            item2Tick3.image = UIImage(named: "redCross")
        }else{
            item2Person3.alpha = 1
            item2Tick3.image = UIImage(named: "blueTick")
        }
        
        self.item2Vector.text = "= (\(item2Vector[0]), \(item2Vector[1]), \(item2Vector[2]))"
        
        
        // Item 3 Vector
        if item3Vector[0] == 0{
            item3Person1.alpha = 0.2
            item3Tick1.image = UIImage(named: "redCross")
        }else{
            item3Person1.alpha = 1
            item3Tick1.image = UIImage(named: "blueTick")
        }
        
        if item3Vector[1] == 0{
            item3Person2.alpha = 0.2
            item3Tick2.image = UIImage(named: "redCross")
        }else{
            item3Person2.alpha = 1
            item3Tick2.image = UIImage(named: "blueTick")
        }
        
        if item3Vector[2] == 0{
            item3Person3.alpha = 0.2
            item3Tick3.image = UIImage(named: "redCross")
        }else{
            item3Person3.alpha = 1
            item3Tick3.image = UIImage(named: "blueTick")
        }
        
        self.item3Vector.text = "= (\(item3Vector[0]), \(item3Vector[1]), \(item3Vector[2]))"
    }
    
    @IBAction func getTapped(_ sender: Any) {
        getButton.isHidden = true
        continueButton.isHidden = false
        heightConstraint.isActive = false
        stackView.isHidden = false
    }
    
    
    @IBAction func continueTapped(_ sender: Any) {
        stepViewDelegate?.nextTapped()
    }
    
    
}
