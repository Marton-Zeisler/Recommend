//
//  GameRecommendationVC.swift
//  Book_Sources
//
//  Created by Marton Zeisler on 2019. 03. 17..
//

import UIKit

public class GameRecommendationVC: UIViewController {
    
    @IBOutlet var greenView: UIView!
    
    @IBOutlet var selectedItem1Image: UIImageView!
    @IBOutlet var selectedItem2Image: UIImageView!
    
    @IBOutlet var recommend1Image: UIImageView!
    @IBOutlet var recommend1Label: UILabel!
    
    @IBOutlet var recommend2Image: UIImageView!
    @IBOutlet var recommend2Label: UILabel!
    
    @IBOutlet var recommendItem: UIImageView!
    @IBOutlet var recommendedLabel: UILabel!
    
    @IBOutlet var bestMatchesLabel: UILabel!
    
    @IBOutlet var line1: UIImageView!
    @IBOutlet var line2: UIImageView!
    
    var selected1Item: Item!
    var selected2Item: Item?
    var products = Products()

    @IBOutlet var introLabel: UILabel!
    @IBOutlet var yourItemsLabel: UILabel!
    @IBOutlet var bestLabel: UILabel!
    @IBOutlet var resetButton: UIButton!
    
    @IBOutlet var recommendView: UIView!
    
    @IBOutlet var noMatchLabel: UILabel!
    @IBOutlet var matchStack: UIStackView!
    
    @IBOutlet var explanationLabel: UILabel!
    
    override public func viewDidLoad() {
        super.viewDidLoad()
        
        // Shadow
        recommendView.layer.shadowColor = UIColor.black.cgColor
        recommendView.layer.shadowOpacity = 0.4
        recommendView.layer.shadowOffset = .zero
        recommendView.layer.shadowRadius = 20
        
        greenView.layer.shadowColor = UIColor.black.cgColor
        greenView.layer.shadowOpacity = 0.4
        greenView.layer.shadowOffset = .zero
        greenView.layer.shadowRadius = 20
        
        setupUI()
    }
    
    public override func viewWillAppear(_ animated: Bool) {
        var fontURL = Bundle.main.url(forResource: "Muli-Bold", withExtension: "ttf")
        CTFontManagerRegisterFontsForURL(fontURL! as CFURL, CTFontManagerScope.process, nil)
        fontURL = Bundle.main.url(forResource: "Muli-SemiBold", withExtension: "ttf")
        CTFontManagerRegisterFontsForURL(fontURL! as CFURL, CTFontManagerScope.process, nil)
        
        introLabel.font = UIFont(name: "Muli-SemiBold", size: 20)
        yourItemsLabel.font = UIFont(name: "Muli-Bold", size: 17)
        bestMatchesLabel.font = UIFont(name: "Muli-Bold", size: 17)
        recommend1Label.font = UIFont(name: "Muli-Bold", size: 16)
        recommend2Label.font = UIFont(name: "Muli-Bold", size: 16)
        bestLabel.font = UIFont(name: "Muli-Bold", size: 14)
        recommendedLabel.font = UIFont(name: "Muli-Bold", size: 13)
        resetButton.titleLabel?.font = UIFont(name: "Muli-Bold", size: 16)
    }
    
    func setupUI(){
        if selected2Item == nil{
            yourItemsLabel.text = "YOUR ITEM"
            bestMatchesLabel.text = "BEST MATCH"
        }else{
            yourItemsLabel.text = "YOUR ITEMS"
            bestMatchesLabel.text = "BEST MATCHES"
        }
        
        // Selected Items
        selectedItem1Image.image = UIImage(named: selected1Item.getWhiteImage())
        
        if let selected2 = selected2Item{
            selectedItem2Image.image = UIImage(named: selected2.getWhiteImage())
        }else{
            line2.isHidden = true
            selectedItem2Image.isHidden = true
            recommend2Image.isHidden = true
            recommend2Label.isHidden = true
        }
        
        // Pair Items
        let lowestForItem1 = products.findLowestPair(item: selected1Item)
        recommend1Image.image = UIImage(named: lowestForItem1.0.getWhiteImage())
        recommend1Label.text = "\(Int(round(lowestForItem1.1)))" + "°" + " [\(Int(abs(((lowestForItem1.1-90)/90) * 100)))% MATCH]"
        
        if let selected2 = selected2Item{
            let lowestForItem2 = products.findLowestPair(item: selected2)
            recommend2Image.image = UIImage(named: lowestForItem2.0.getWhiteImage())
            recommend2Label.text = "\(Int(round(lowestForItem2.1)))" + "°" + " [\(Int(abs(((lowestForItem2.1-90)/90) * 100)))% MATCH]"
            
            let (explanation, matchItem) = products.findBestMatchFor2Items(item1: selected1Item, item2: selected2)
            explanationLabel.text = explanation
            
            if let match = matchItem{
                recommendItem.image = UIImage(named: match.getItemImage())
                recommendedLabel.text = match.rawValue
            }else{
                matchStack.isHidden = true
                noMatchLabel.isHidden = false
            }
        }else{
            if lowestForItem1.1 == 90.0{
                matchStack.isHidden = true
                noMatchLabel.isHidden = false
                explanationLabel.text = "We couldn't find a recommendation for your item."
            }else{
                recommendItem.image = UIImage(named: lowestForItem1.0.getItemImage())
                recommendedLabel.text = lowestForItem1.0.rawValue
                explanationLabel.text = "We found a best match for your item, so therefore we recommend you to add \(lowestForItem1.0.rawValue) to your basket."
            }
        }
    }
    
    @IBAction func resetTapped(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }

}

extension GameRecommendationVC {
    class public func loadFromStoryboard() -> UIViewController? {
        let storyboard = UIStoryboard.init(name: "Main", bundle: nil)
        return storyboard.instantiateViewController(withIdentifier: "GameRecommendationVC") as! GameRecommendationVC
    }
}
